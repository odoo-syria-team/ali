from . import moves_history
from . import crm_inherit
from . import document
from . import sale_order
from . import input_for_vendor
from . import purchase_order